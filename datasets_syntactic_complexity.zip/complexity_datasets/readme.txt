This directory contains the datasets used in our paper. They are all in plain-text files with tab-delimited fields.

* ambiguity_dataset.txt *

The ambiguous vs. non-ambiguous triples, with fields:

- ambiguous attachment
- high attachment
- low attachment

* center_right_clauses.txt *

The center-embedding vs. right-branching minimal pairs, with fields:

- center embedding
- right branching

* that_vs_and-c2.txt *

The subordination vs. coordination contrast, 2-clause pairs, with fields:

- subordinated
- coordinated

* that_vs_and-c3.txt *

The subordination vs. coordination contrast, 3-clause pairs, with fields:

- subordinated
- coordinated

* that_vs_and-c4.txt *

The subordination vs. coordination contrast, 4-clause pairs, with fields:

- subordinated
- coordinated
